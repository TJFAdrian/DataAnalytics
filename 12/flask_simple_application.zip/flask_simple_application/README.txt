#------------------------------------------------------------------------------------
# Flask simple application
#------------------------------------------------------------------------------------

# Open Anaconda console and activate your conda environment

# cd into the folder 'flask_simple_application'

# Run the Python script app.py by typing
python app.py 

# Open the web application in a web browser by using the url shown by flask, e.g.
http://127.0.0.1:5000

# Change the parameters in the url, e.g.:
http://127.0.0.1:5000/hello/Peter


