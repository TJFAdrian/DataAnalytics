TITLE = 'Plot with flask and matplotlib'
