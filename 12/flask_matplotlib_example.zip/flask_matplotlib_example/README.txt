#------------------------------------------------------------------------------------
# Flask with Matplotlib example
#------------------------------------------------------------------------------------

# Open Anaconda console and activate your environment

# cd into the folder 'flask_matplotlib_example'

# Run the Python script app.py by typing
python app.py 

# Access the web application in a web browser using: 
http://127.0.0.1:5000/500

# Change the parameter (i.e. number of observations), e.g.:
http://127.0.0.1:5000/10
http://127.0.0.1:5000/100
http://127.0.0.1:5000/1000
http://127.0.0.1:5000/10000


